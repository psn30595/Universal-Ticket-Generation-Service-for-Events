﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TicketAPI.Models;
using TicketAPI.Repositories;


namespace TicketAPI.Controllers
{
    public class ContactController : ApiController
    {
        public System.Web.Mvc.ActionResult view()
        {
            return view();
        }
        [HttpPost]
        [Route("BookTicket")]
        public bool BookTicket(Values contact)
        {

            if (contact == null)
            {
                return false;
            }
            else
            {
                PdfGenerator pg = new PdfGenerator(); //for PDF generation
                pg.GeneratePdf(contact);
                //Console.Write("<p>Test</p>");
                // HttpClient client = new HttpClient();
                // client.BaseAddress = new Uri("https://api.qrserver.com/v1/create-qr-code/?data=HelloWorld&amp;size=100x100");
                TicketRepository db = new TicketRepository(); //database connection
               // db.AddDetailToDB(contact);   //insert values in database
                return true;

                //  return client.BaseAddress;
            }
        }
    }
}