﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TicketAPI.Models
{
    public class Values
    {
        //retrieving values from client application
        public string CEmail { get; set; }
        public string EName { get; set; }
        public string Edate { get; set; }
        public string Etime { get; set; }
        public string Evenue { get; set; }
        public string Ttype { get; set; }
        public string Tquantity { get; set; }
        public string Trate { get; set; }

        // EName, Edate, Etime, Evenue, Ttype, Tquantity, Trate

    }
}