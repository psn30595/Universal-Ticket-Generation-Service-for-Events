﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TicketAPI.Models;
using System.Data.SqlClient;
using System.Data;
using Newtonsoft.Json;
using System.Threading.Tasks;
using System.Net.Http;
using System.Text;
namespace TicketAPI.Repositories
{
    public class TicketRepository
    {
        public void AddDetailToDB(Values contact)
        {
            //starting connection and storing values in database
            var connectString = "Data Source = piyushserver.database.windows.net; Initial Catalog = ApiDB; User ID = psn30595; Password = Kapilan1993";
 
            var query = "INSERT INTO BookTicke (EName, Edate, Etime, Evenue, Ttype, Tquantity, Trate) VALUES ('" + contact.EName + "', '" + contact.Edate + "', '" + contact.Etime + "', '" + contact.Evenue + "', '" + contact.Ttype + "', '" + contact.Tquantity + "', '" + contact.Trate + "')";

            // EName, Edate, Etime, Evenue, Ttype, Tquantity, Trate
            //SQL connection started
            SqlConnection connection = new SqlConnection(connectString);


            try
            {
                connection.Open();

                SqlCommand command = new SqlCommand(query, connection);
                command.ExecuteNonQuery();
                connection.Dispose();
                command.Dispose();
                connection.Close();//close SQL connection

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}