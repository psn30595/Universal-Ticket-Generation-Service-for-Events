﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using TicketAPI.Models;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Net;


namespace TicketAPI.Repositories
{
    public class PdfGenerator
    {
        public object Response { get; private set; }

        //        public static void Generatepdf(Contacts contact)
        public void GeneratePdf(Values contact)
        {
            // EName, Edate, Etime, Evenue, Ttype, Tquantity, Trate

            string s1 = contact.EName;
            string s2 = contact.Edate;
            string s3 = contact.Etime;
            string s4 = contact.Evenue;
            string s5 = contact.Ttype;
            string s6 = contact.Tquantity;
            string s7 = contact.Trate;
        
            //random number generator for ticket number (6digit number)
            Random generator = new Random();
            String r = generator.Next(0, 999999).ToString("D6");

            //3rd party API for generating QR code based on ticket number
            var url = string.Format("http://chart.apis.google.com/chart?cht=qr&chs=200x200&chl="+r);
            WebResponse response = default(WebResponse);
            Stream remoteStream = default(Stream);
            StreamReader readStream = default(StreamReader);
            WebRequest request = WebRequest.Create(url);
            response = request.GetResponse();
            remoteStream = response.GetResponseStream();
            readStream = new StreamReader(remoteStream);
            System.Drawing.Image img = System.Drawing.Image.FromStream(remoteStream);
            string p = @"C:/Users/Piyush/Desktop/Api/Zfolder/1.png";
            img.Save(p);
            

            Document doc = new Document(iTextSharp.text.PageSize.LETTER, 10, 10, 42, 35);
                
            string path = @"C:\Users\Piyush\Desktop\Api\Zfolder\1.pdf";
            //started with generating PDF
    
            PdfWriter wri = PdfWriter.GetInstance(doc, new FileStream(path, FileMode.Create));
           // PdfWriter wri = PdfWriter.GetInstance(doc, MemoryStream);

            doc.Open();
            string imageURL = p;
           Image jpg = Image.GetInstance(imageURL);
            Paragraph paragraph = new Paragraph(  r + '\n' + s1 + "\n" + s2 + "\n" + s3 + "\n" + s4 + "\n" + s5 + "\n" + s6 + "\n" + s7);
            doc.Add(paragraph);
            doc.Add(jpg);
            doc.Close();

              HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.ContentType = "application/pdf";
            HttpContext.Current.Response.AddHeader("content-desposition","ticket.pdf");
           HttpContext.Current.Response.Write(doc);
            
           HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            HttpContext.Current.Response.End();
            HttpContext.Current.Response.Flush();
           HttpContext.Current.Response.Clear();
            

            /*

                        Response.Clear();
                        Response.Write("<html><body onload=\"parent.OpenPDF('tmp/" + Path.GetFileName(sPdfFile) + "');\"></body></html>"); 
                        Response.End();

                        Response.Clear();
                        Response.ContentType = "application/pdf";
                        Response.AppendHeader("Content-Disposition", "attachment; filename=foo.pdf");
                        Response.TransmitFile(MemoryStream);
                        Response.End();
                        */
            // File for Azure

            //HttpContext.Current.Response.Clear();
            //HttpContext.Current.Response.ContentType = "application/pdf";
            //byte[] pdfBytes = MemoryStream.ToArray();
            //HttpContext.Current.Response.AppendHeader("Content-Length", pdfBytes.Length.ToString());
            //HttpContext.Current.Response.OutputStream.Write(pdfBytes, 0, (int)pdfBytes.Length);
        }
    }
}


/*
protected void Page_Load(object sender, EventArgs e)
{
    ShowPdf(CreatePDF2());
}

private byte[] CreatePDF2()
{
    Document doc = new Document(PageSize.LETTER, 50, 50, 50, 50);

    using (MemoryStream output = new MemoryStream())
    {
        PdfWriter wri = PdfWriter.GetInstance(doc, output);
        doc.Open();

        Paragraph header = new Paragraph("My Document") {Alignment = Element.ALIGN_CENTER};
        Paragraph paragraph = new Paragraph("Testing the iText pdf.");
        Phrase phrase = new Phrase("This is a phrase but testing some formatting also. \nNew line here.");
        Chunk chunk = new Chunk("This is a chunk.");

        doc.Add(header);
        doc.Add(paragraph);
        doc.Add(phrase);
        doc.Add(chunk);

        doc.Close();
        return output.ToArray();
    }

}

private void ShowPdf(byte[] strS)
{
    Response.ClearContent();
    Response.ClearHeaders();
    Response.ContentType = "application/pdf";
    Response.AddHeader("Content-Disposition", "attachment; filename=" + DateTime.Now);

    Response.BinaryWrite(strS);
    Response.End();
    Response.Flush();
    Response.Clear();
}
    */
