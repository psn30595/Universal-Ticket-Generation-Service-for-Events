﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EventTracker.Model
{
    public class Concert
    {
        public string Name { get; set; }
        public string City { get; set; }
        public string Date { get; set; }
        public string Time { get; set; }
        public string DateTime { get; set; }
        public string Venue { get; set; }
        public class StrConcert
        {
            
        }
    }
}