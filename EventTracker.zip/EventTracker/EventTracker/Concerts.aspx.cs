﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;
using System.Text;
using EventTracker.Model;


namespace EventTracker
{
    public partial class Concerts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public void onClickSearch(object sender, EventArgs e)
        {
            try
            {
                Concert concertList = new Concert();
                concertList.Date = ddlDate.Text.ToString();
                concertList.City = ddlCity.Text.ToString();
                FilterItem(concertList);
            }
            catch(Exception ex)
            {
                throw ex;
            }

            
        }

        //public async Task<bool> FilterItem(Concert concertList)
        public List<Concert> FilterItem(Concert concertList)
        {
            List<Concert> lstconcerts = new List<Concert>();

            try
            {
                var client = new HttpClient();
                var JsonContent = JsonConvert.SerializeObject(concertList);
                var httpContent = new StringContent(JsonContent, Encoding.UTF8, "application/json");
                var response = client.PostAsync("http://concertservice.azurewebsites.net/FilterItem", httpContent).Result;
                var resultContent = response.Content.ReadAsStringAsync().Result;
                lstconcerts = JsonConvert.DeserializeObject<List<Concert>>(resultContent);


                GridView1.DataSource = lstconcerts;
                GridView1.DataBind();
                //var responseString = await response.Content.ReadAsStringAsync();
                //lstconcerts = response.ToList();
                return lstconcerts;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}